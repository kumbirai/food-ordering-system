package com.kumbirai.udemy.food.ordering.common.entity;

public abstract class AggregateRoot<ID> extends BaseEntity<ID>
{
}
