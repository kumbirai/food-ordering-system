package com.kumbirai.udemy.food.ordering.common.valueobject;

public enum OrderStatus
{
	PENDING,
	PAID,
	APPROVED,
	CANCELLING,
	CANCELLED;
}
