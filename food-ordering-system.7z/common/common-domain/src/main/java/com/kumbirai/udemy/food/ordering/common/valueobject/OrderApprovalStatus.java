package com.kumbirai.udemy.food.ordering.common.valueobject;

public enum OrderApprovalStatus
{
	APPROVED,
	REJECTED;
}
