package com.kumbirai.udemy.food.ordering.domain.entity;

public class OrderTest
{
}
